#include "guava_demo.h"


int main()
{
	guava_demo temp;
	temp.run();

	return 0;
}









